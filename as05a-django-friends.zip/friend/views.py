
from django.shortcuts import get_object_or_404, render
from .models import Friend


def friend_list(request):
    friends = Friend.objects.all()
    return render(request, 'friend/list.html', {'friends': friends})


def friend_detail(request, pk):
    friend = get_object_or_404(Friend, pk=pk)
    return render(request, 'friend/detail.html', {'friend': friend})
