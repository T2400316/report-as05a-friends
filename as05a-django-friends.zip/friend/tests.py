
from django.test import TestCase
from django.urls import reverse

from .models import Friend


class FriendViewTests(TestCase):

    def test_empty_list(self):
        """Friendが0件でも一覧ページが表示される"""
        response = self.client.get(reverse('friend_list'))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, '友達一覧')

    def test_list_shows_friends(self):
        """複数のFriendの名前と詳細ページへのリンクが表示される"""
        friend1 = Friend.objects.create(
            name='田中太郎',
            nickname='たろう'
        )
        friend2 = Friend.objects.create(
            name='山田花子',
            nickname='はなこ'
        )

        response = self.client.get(reverse('friend_list'))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, '田中太郎')
        self.assertContains(response, '山田花子')

        self.assertContains(
            response,
            reverse('friend_detail', args=[friend1.pk])
        )
        self.assertContains(
            response,
            reverse('friend_detail', args=[friend2.pk])
        )

    def test_detail_shows_name_and_nickname(self):
        """詳細ページに名前とニックネームが表示される"""
        friend = Friend.objects.create(
            name='佐藤次郎',
            nickname='じろう'
        )

        response = self.client.get(
            reverse('friend_detail', args=[friend.pk])
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, '佐藤次郎')
        self.assertContains(response, 'じろう')

    def test_missing_friend_returns_404(self):
        """存在しないFriendの詳細ページは404を返す"""
        response = self.client.get(
            reverse('friend_detail', args=[99999])
        )

        self.assertEqual(response.status_code, 404)
