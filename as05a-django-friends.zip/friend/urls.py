
from django.urls import path
from . import views

urlpatterns = [
    path('list/', views.friend_list, name='friend_list'),
    path('detail/<int:pk>/', views.friend_detail, name='friend_detail'),
]
